import tkinter as tk
import random, os, math, sys, time, json
from collections import deque

# ---------- SOUND EFFECTS + BGM ----------
# The game ships with its own short, synthesized WAV audio so it does not
# depend on internet access or copyrighted recordings.  The melodies use
# bright plucked tones and simple percussion for a Filipino fiesta/barangay
# flavor.  Windows uses winsound because it is built into Python; on other
# systems the game remains fully playable and simply runs silently.
try:
    import winsound
    _HAS_WINSOUND = True
except ImportError:
    _HAS_WINSOUND = False

AUDIO_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "audio")
current_bgm = None

def _audio_path(name):
    return os.path.join(AUDIO_DIR, name + ".wav")

def play_sound(kind):
    if not sound_enabled or not _HAS_WINSOUND:
        return
    path = _audio_path(kind)
    if not os.path.exists(path):
        return
    try:
        winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
    except Exception:
        pass

def stop_bgm():
    global current_bgm
    if not _HAS_WINSOUND:
        current_bgm = None
        return
    try:
        winsound.PlaySound(None, winsound.SND_PURGE)
    except Exception:
        pass
    current_bgm = None

def play_bgm(track):
    global current_bgm
    if not sound_enabled or not _HAS_WINSOUND:
        return
    if current_bgm == track:
        return
    path = _audio_path(track)
    if not os.path.exists(path):
        return
    try:
        winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP | winsound.SND_NODEFAULT)
        current_bgm = track
    except Exception:
        current_bgm = None

def refresh_bgm():
    if not sound_enabled:
        stop_bgm()
        return
    if not in_game:
        play_bgm("lobby_bgm")
    elif boss_level:
        play_bgm("boss_bgm")
    elif night_mode:
        play_bgm("night_bgm")
    else:
        play_bgm("barangay_bgm")

root = tk.Tk()
root.title("Mission: Tumakas")
root.configure(bg="black")
root.attributes("-fullscreen", True)
# Escape is used by the game for pause; fullscreen stays on during play.
root.bind("<F11>", lambda e: root.attributes("-fullscreen", not root.attributes("-fullscreen")))

# ---------- ONE PERSISTENT CANVAS FOR THE WHOLE APP ----------
# BUGFIX: the previous version created a brand-new full-size Canvas every
# time it switched between the lobby and the maze, then destroyed the old
# one. On some Linux window managers that leaves stale pixels behind in
# the window's backing store (the widget is genuinely gone, but the
# compositor doesn't always repaint that region), which is exactly the
# "ghost walls/player behind the lobby" bug. The fix is to never destroy
# the drawing surface at all: create ONE canvas once, and every screen
# just calls main_cv.delete("all") and redraws onto it. Tk always repaints
# a canvas correctly on delete("all") since it's the same widget/drawable,
# so this removes the whole class of ghosting bugs.
SW = root.winfo_screenwidth()
SH = root.winfo_screenheight()
main_cv = tk.Canvas(root, width=SW, height=SH, highlightthickness=0, bg="#050014")
main_cv.pack(fill="both", expand=True)

# Responsive gameplay layout. The maze now expands to the available
# screen instead of staying at the old 560x560 size.
GAME_MARGIN_X = 22
GAME_TOP = 118
GAME_BOTTOM = 86
GAME_W = max(640, SW - GAME_MARGIN_X * 2)
GAME_H = max(480, SH - GAME_TOP - GAME_BOTTOM)
GAME_X0 = (SW - GAME_W) // 2
GAME_Y0 = GAME_TOP
HUD_H = 58
HUD_Y0 = 12

SAVE = "mission_tumakas_save.json"
level, points, skin, owned, lives = 1, 0, "white", ["white"], 3
theme_name = "Bahay Kubo"
best_times = {}
keys_collected = 0
keys_required = 3
keys = {}
explored = set()
paused = False
game_over_window = None
level_start_time = 0.0
combo = 0
combo_timer = 0
objective = ""
mission_event = None
event_done = False
npcs = []
vehicles = []
shortcuts = {}
night_mode = False
boss_level = False
boss = None
store_open = False
sound_enabled = True

skins = {
    "talahib": (30, "#8fbf5a"),
    "sampaguita": (50, "#f5f1d8"),
    "mangga": (75, "#e0ad2f"),
    "banaba": (100, "#b36bb3"),
    "dagat": (250, "#4da6c9"),
    "bahaghari": (500, "chroma")
}

# ---------- ITEM / POWER-UP DEFINITIONS ----------
# Each box you find in the maze gives a random reward from this table.
ITEM_TYPES = ["sipa", "kalesa", "payong", "mangga"]
ITEM_COLORS = {"sipa": "#b52b3a", "kalesa": "#2f7d6d", "payong": "#d49b2a", "mangga": "#6a9f3a"}
ITEM_LABELS = {"sipa": "SIPA", "kalesa": "BILIS", "payong": "KALASAG", "mangga": "+5"}

# ---------- ENEMY VARIETY ----------
# Three visually distinct enemy "species". They all use the same chase
# logic, just drawn differently so the maze doesn't feel like one repeated
# red dot chasing you.
ENEMY_KINDS = ["ghost", "spike", "blob"]
ENEMY_PALETTE = {
    "ghost": ("#b266ff", "#5e00b3"),
    "spike": ("#ff5566", "#8a0011"),
    "blob":  ("#ff9933", "#7a3d00"),
}
# ---------- PER-SPECIES STATS ----------
# hp: how many gun shots it takes to put one down.
# interval_delta: added to the level-scaled base move interval
# (enemy_tick) -- negative = faster than normal, positive = slower.
# phase_chance: chance per step that this kind ignores a single wall
# and phases straight toward the player instead of pathfinding around it.
ENEMY_STATS = {
    "spike": {"hp": 1, "interval_delta": -1, "phase_chance": 0.0},
    "blob":  {"hp": 2, "interval_delta": +2, "phase_chance": 0.0},
    "ghost": {"hp": 1, "interval_delta": 0,  "phase_chance": 0.10},
}

# Filipino visual themes. These change the actual game board, not just labels.
THEMES = {
    "Bahay Kubo": {
        "top": "#dce9b4", "bottom": "#8fbf73", "wall": "#6f4e37",
        "floor": "#d9c58a", "accent": "#b52b3a", "trim": "#f2d16b"
    },
    "Palengke": {
        "top": "#f7dfb0", "bottom": "#d89a62", "wall": "#7a4930",
        "floor": "#ead6a8", "accent": "#1e6f5c", "trim": "#e7c24f"
    },
    "Pista": {
        "top": "#b8d8e8", "bottom": "#6da4b8", "wall": "#654d3b",
        "floor": "#d8c58b", "accent": "#b52b3a", "trim": "#f0c83d"
    },
}

# global handle for whatever background animation loop is currently running
# (starfield in the lobby, torch flicker in the maze) so we can cancel it
# cleanly whenever we switch screens instead of stacking multiple loops.
anim_job = None
stars = []
floaters = []   # decorative drifting shapes behind the lobby UI
particles = []  # short-lived burst particles (item pickups, kills, hits)
tick_frame = 0

# BUGFIX: relying only on root.after_cancel(anim_job) turned out to be
# fragile -- a stray scheduled frame could still slip through right as a
# level finished, leaving old maze walls/player drawn behind the new
# lobby screen. `screen_gen` is a generation counter: every time we
# switch screens we bump it, and every animation loop checks its own
# captured generation before doing anything, so any leftover callback
# from the previous screen is a guaranteed no-op instead of a race.
screen_gen = 0
in_game = False  # whether the maze/HUD should currently be drawn on main_cv

# ================= COLOR HELPERS =================

def lerp_color(c1, c2, t):
    c1 = c1.lstrip("#"); c2 = c2.lstrip("#")
    r1, g1, b1 = int(c1[0:2],16), int(c1[2:4],16), int(c1[4:6],16)
    r2, g2, b2 = int(c2[0:2],16), int(c2[2:4],16), int(c2[4:6],16)
    r = int(r1 + (r2-r1)*t); g = int(g1 + (g2-g1)*t); b = int(b1 + (b2-b1)*t)
    return f"#{r:02x}{g:02x}{b:02x}"

def draw_gradient(cv, x0, y0, w, h, top, bottom, tag="bg"):
    steps = 48
    for i in range(steps):
        t0, t1 = i/steps, (i+1)/steps
        col = lerp_color(top, bottom, t0)
        cv.create_rectangle(x0, y0+h*t0, x0+w, y0+h*t1+1, fill=col, outline="", tags=tag)

def regular_polygon(cv, cx, cy, r, sides, rot, **kw):
    pts = []
    for i in range(sides):
        ang = rot + 2*math.pi*i/sides
        pts += [cx + r*math.cos(ang), cy + r*math.sin(ang)]
    return cv.create_polygon(pts, **kw)

def draw_mini_character(cv, cx, cy, r, color, bob=0.0):
    """Small human avatar used in menus/shop."""
    cy += bob
    skin_col = "#c98a5b"
    hair = "#2b1a12"
    shirt = color if color != "chroma" else "#b52b3a"
    # shadow
    cv.create_oval(cx-r*.7, cy+r*.75, cx+r*.7, cy+r, fill="#000000", outline="")
    # legs + shoes
    cv.create_rectangle(cx-r*.28, cy+r*.25, cx-r*.05, cy+r*.82, fill="#244a66", outline="")
    cv.create_rectangle(cx+r*.05, cy+r*.25, cx+r*.28, cy+r*.82, fill="#244a66", outline="")
    cv.create_oval(cx-r*.36, cy+r*.70, cx-r*.02, cy+r*.90, fill="#2f2f2f", outline="")
    cv.create_oval(cx+r*.02, cy+r*.70, cx+r*.36, cy+r*.90, fill="#2f2f2f", outline="")
    # torso
    cv.create_rectangle(cx-r*.45, cy-r*.10, cx+r*.45, cy+r*.42, fill=shirt, outline="#3d1a22", width=1)
    # arms
    cv.create_oval(cx-r*.62, cy-r*.02, cx-r*.30, cy+r*.35, fill=shirt, outline="#3d1a22")
    cv.create_oval(cx+r*.30, cy-r*.02, cx+r*.62, cy+r*.35, fill=shirt, outline="#3d1a22")
    # neck + head
    cv.create_rectangle(cx-r*.14, cy-r*.30, cx+r*.14, cy-r*.08, fill=skin_col, outline="")
    cv.create_oval(cx-r*.43, cy-r*.82, cx+r*.43, cy-r*.12, fill=skin_col, outline="#6f4e37", width=1)
    # hair cap / fringe
    cv.create_arc(cx-r*.46, cy-r*.92, cx+r*.46, cy-r*.20, start=180, extent=180, fill=hair, outline=hair)
    cv.create_oval(cx-r*.28, cy-r*.62, cx-r*.12, cy-r*.42, fill="#2a1a12", outline="")
    cv.create_oval(cx+r*.12, cy-r*.62, cx+r*.28, cy-r*.42, fill="#2a1a12", outline="")
    # eyes
    cv.create_oval(cx-r*.22, cy-r*.48, cx-r*.13, cy-r*.39, fill="#111", outline="")
    cv.create_oval(cx+r*.13, cy-r*.48, cx+r*.22, cy-r*.39, fill="#111", outline="")

# ---------- PARTICLE BURSTS ----------
# Lightweight one-shot particle effect used for item pickups, gun kills
# and hits. Particles live in a flat list and are advanced/drawn once per
# frame from inside draw(), same as the player trail.
def spawn_particles(cx, cy, color, n=10, speed=3.0, life=14):
    for _ in range(n):
        ang = random.uniform(0, math.pi*2)
        spd = random.uniform(speed*0.4, speed)
        particles.append({
            "x": cx, "y": cy,
            "vx": math.cos(ang)*spd, "vy": math.sin(ang)*spd,
            "life": life, "max_life": life, "color": color,
        })

def update_and_draw_particles(cv):
    alive = []
    for p in particles:
        p["x"] += p["vx"]
        p["y"] += p["vy"]
        p["vx"] *= 0.9
        p["vy"] *= 0.9
        p["life"] -= 1
        if p["life"] <= 0:
            continue
        t = p["life"] / p["max_life"]
        sz = 3 * t + 0.5
        cv.create_oval(p["x"]-sz, p["y"]-sz, p["x"]+sz, p["y"]+sz,
                        fill=p["color"], outline="")
        alive.append(p)
    particles[:] = alive

def theme_colors():
    t = THEMES.get(theme_name, THEMES["Bahay Kubo"])
    return t["top"], t["bottom"], t["wall"]

def current_theme():
    return THEMES.get(theme_name, THEMES["Bahay Kubo"])

# ================= SAVE / LOAD =================

def area_name():
    if level <= 10: return "SITIO"
    if level <= 20: return "BARANGAY"
    if level <= 40: return "PALENGKE"
    if level <= 60: return "PISTA"
    if level <= 80: return "TABING-DAGAT"
    return "LUMANG BARANGAY"

def area_theme():
    names = {"SITIO":"Bahay Kubo", "BARANGAY":"Bahay Kubo", "PALENGKE":"Palengke", "PISTA":"Pista", "TABING-DAGAT":"Pista", "LUMANG BARANGAY":"Bahay Kubo"}
    return names[area_name()]

def save():
    data = {
        "level": max(1, int(level)),
        "points": max(0, int(points)),
        "skin": skin if skin in ["white"] + list(skins) else "white",
        "owned": [x for x in owned if x in ["white"] + list(skins)],
        "theme": theme_name if theme_name in THEMES else "Bahay Kubo",
        "best_times": {str(k): float(v) for k, v in best_times.items()},
        "sound_enabled": bool(sound_enabled),
    }
    if "white" not in data["owned"]:
        data["owned"].insert(0, "white")
    try:
        with open(SAVE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass

def load():
    global level, points, skin, owned, theme_name, best_times, sound_enabled
    try:
        if not os.path.exists(SAVE):
            return
        with open(SAVE, encoding="utf-8") as f:
            d = json.load(f)
        level = max(1, min(100, int(d.get("level", 1))))
        points = max(0, int(d.get("points", 0)))
        skin = d.get("skin", "white")
        if skin not in ["white"] + list(skins):
            skin = "white"
        owned = [x for x in d.get("owned", ["white"]) if x in ["white"] + list(skins)]
        if "white" not in owned:
            owned.insert(0, "white")
        theme_name = d.get("theme", "Bahay Kubo")
        sound_enabled = bool(d.get("sound_enabled", True))
        if theme_name not in THEMES:
            theme_name = "Bahay Kubo"
        raw_best = d.get("best_times", {})
        best_times = {}
        if isinstance(raw_best, dict):
            for k, v in raw_best.items():
                try:
                    best_times[int(k)] = float(v)
                except (TypeError, ValueError):
                    pass
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        level, points, skin, owned = 1, 0, "white", ["white"]
        theme_name, best_times = "Bahay Kubo", {}
        sound_enabled = True

def clear():
    global anim_job, screen_gen, in_game, celebrating
    celebrating = False
    screen_gen += 1  # invalidates any in-flight animation callback immediately
    in_game = False
    if anim_job is not None:
        try:
            root.after_cancel(anim_job)
        except Exception:
            pass
        anim_job = None
    # destroy every overlay widget (buttons/labels/frames) EXCEPT the one
    # persistent drawing canvas -- that canvas is never torn down, only
    # cleared, which is what avoids the ghosting bug described above.
    for w in root.winfo_children():
        if w is main_cv:
            continue
        w.destroy()
    main_cv.delete("all")
    root.unbind("<KeyPress>")
    root.unbind("<Button-1>")
    particles.clear()
    stop_bgm()

def styled_button(parent, text, command, fg="white", w=26, h=50, font_size=12):
    """Custom flat Filipino-game button.
    Uses a Frame + Labels instead of the platform's native Tk button, so
    every clickable control has the same designed appearance on Windows,
    Linux and macOS.  The small side ornaments also make each control feel
    like part of the barangay UI rather than a default OS widget.
    """
    normal = "#2a1730"
    hover = "#5a3328"
    frame = tk.Frame(parent, bg=normal, bd=1, relief="solid",
                     highlightthickness=1, highlightbackground="#caa66a",
                     cursor="hand2", width=max(80, int(w*12)), height=h)
    frame.pack_propagate(False)

    left = tk.Label(frame, text="✦", bg=normal, fg=fg,
                    font=("Arial", max(9, font_size), "bold"))
    left.pack(side="left", padx=10)
    label = tk.Label(frame, text=text, bg=normal, fg=fg,
                     font=("Arial", font_size, "bold"), anchor="center")
    label.pack(side="left", fill="both", expand=True)
    right = tk.Label(frame, text="✦", bg=normal, fg=fg,
                     font=("Arial", max(9, font_size), "bold"))
    right.pack(side="right", padx=10)

    def set_bg(color):
        for widget in (frame, left, label, right):
            widget.configure(bg=color)

    def on_enter(_event):
        set_bg(hover)
        frame.configure(highlightbackground=fg)

    def on_leave(_event):
        set_bg(normal)
        frame.configure(highlightbackground="#caa66a")

    def on_click(_event):
        play_sound("menu")
        command()

    for widget in (frame, left, label, right):
        widget.bind("<Enter>", on_enter)
        widget.bind("<Leave>", on_leave)
        widget.bind("<Button-1>", on_click)

    # Keyboard focus is intentionally unnecessary: game controls remain
    # keyboard-driven while menu buttons are mouse/touch-friendly.
    return frame

# ================= FILIPINO VISUAL HELPERS =================

def draw_parol(cv, cx, cy, r, color, tags=None):
    pts = []
    for i in range(10):
        a = -math.pi/2 + i * math.pi/5
        rr = r if i % 2 == 0 else r*0.42
        pts.extend([cx + math.cos(a)*rr, cy + math.sin(a)*rr])
    cv.create_polygon(pts, fill=color, outline="#7b3f00", width=2, tags=tags)
    cv.create_oval(cx-3, cy-3, cx+3, cy+3, fill="#fff4a8", outline="", tags=tags)

def draw_bahay_kubo(cv, cx, cy, scale=1.0):
    # Simple hand-drawn silhouette: roof, bamboo walls, raised floor, stairs.
    w, h = 190*scale, 90*scale
    roof = [(cx-w/2, cy-5*scale), (cx, cy-58*scale),
            (cx+w/2, cy-5*scale), (cx+w*0.38, cy+2*scale),
            (cx, cy-39*scale), (cx-w*0.38, cy+2*scale)]
    cv.create_polygon(roof, fill="#7a4930", outline="#4b2e1f", width=max(1,int(2*scale)))
    cv.create_rectangle(cx-w*0.38, cy, cx+w*0.38, cy+52*scale,
                        fill="#c7a86a", outline="#5d432b", width=max(1,int(2*scale)))
    for dx in (-0.25, 0, 0.25):
        cv.create_line(cx+dx*w, cy, cx+dx*w, cy+52*scale, fill="#8a6a3e", width=1)
    cv.create_rectangle(cx-16*scale, cy+12*scale, cx+16*scale, cy+52*scale,
                        fill="#6f4e37", outline="#3e2b20")
    cv.create_rectangle(cx-w*0.20, cy+10*scale, cx-w*0.04, cy+25*scale,
                        fill="#e7f2e5", outline="#5d432b")
    cv.create_rectangle(cx+w*0.04, cy+10*scale, cx+w*0.20, cy+25*scale,
                        fill="#e7f2e5", outline="#5d432b")
    cv.create_line(cx-w*0.35, cy+55*scale, cx+w*0.35, cy+55*scale, fill="#5d432b", width=3)
    cv.create_line(cx+25*scale, cy+55*scale, cx+48*scale, cy+82*scale, fill="#5d432b", width=3)
    cv.create_line(cx+48*scale, cy+82*scale, cx+65*scale, cy+82*scale, fill="#5d432b", width=3)

def draw_theme_background():
    t = current_theme()
    draw_gradient(main_cv, 0, 0, SW, SH, t["top"], t["bottom"])
    # More unmistakably Filipino scenery: woven bamboo, rice fields,
    # bahay kubo, sari-sari store, jeepney, coconut trees and parol.
    draw_basket_pattern(main_cv, 0, 0, SW, SH, tags="theme")
    draw_mountain(main_cv, 70, SH-210, 1.35, tags="theme")
    draw_ricefield(main_cv, 0, SH-125, SW, 125, tags="theme")
    draw_cloud(main_cv, 90, 105, .8, tags="theme")
    draw_cloud(main_cv, SW-260, 125, .7, tags="theme")
    draw_coconut(main_cv, SW-105, SH-55, .9)
    draw_bahay_kubo(main_cv, 135, SH-120, .72)
    draw_sari_sari(main_cv, SW-275, SH-118, .72)
    draw_jeepney(main_cv, SW-535, SH-55, .55)
    draw_parol(main_cv, 48, 70, 28, t["accent"], tags="theme")
    # Bamboo corner posts
    for xx in (18, SW-18):
        main_cv.create_line(xx,0,xx,SH,fill="#8b6339",width=8,tags="theme")
        for yy in range(20,SH,46):
            main_cv.create_line(xx-5,yy,xx+5,yy+18,fill="#d1a15b",width=2,tags="theme")

# ================= LOBBY (with animated starfield) =================

def draw_cloud(cv, x, y, s=1.0, fill="#fff8df", tags=None):
    cv.create_oval(x, y+12*s, x+70*s, y+48*s, fill=fill, outline="", tags=tags)
    cv.create_oval(x+20*s, y, x+62*s, y+38*s, fill=fill, outline="", tags=tags)
    cv.create_oval(x+48*s, y+8*s, x+95*s, y+45*s, fill=fill, outline="", tags=tags)

def draw_coconut(cv, x, y, s=1.0):
    cv.create_line(x, y, x+8*s, y-100*s, fill="#6f4e37", width=max(2,int(7*s)))
    for ang in [-2.6,-2.0,-1.5,-1.0,-0.5,-0.15]:
        ex=x+8*s+math.cos(ang)*48*s; ey=y-100*s+math.sin(ang)*38*s
        cv.create_line(x+8*s,y-100*s,ex,ey,fill="#3f7c3b",width=max(2,int(7*s)))

def draw_banderitas(cv, y, accent, tags=None):
    cv.create_line(0,y,SW,y,fill="#6f4e37",width=2,tags=tags)
    cols=[accent,"#f0c83d","#2f7d6d","#b36bb3","#e08b36"]
    step=max(44,SW//18)
    for i,x in enumerate(range(0,SW+step,step)):
        col=cols[i%len(cols)]
        cv.create_polygon(x,y,x+step*.55,y,x+step*.28,y+30,fill=col,outline="#6f4e37",width=1,tags=tags)

def draw_jeepney(cv, x, y, s=1.0):
    w=230*s; h=70*s
    cv.create_rectangle(x,y-h*.45,x+w,y,fill="#d7a83d",outline="#4b3522",width=2)
    cv.create_rectangle(x+w*.08,y-h*.32,x+w*.86,y-h*.02,fill="#2f6f73",outline="#4b3522")
    for i in range(4):
        wx=x+w*.16+i*w*.18
        cv.create_rectangle(wx,y-h*.28,wx+w*.10,y-h*.08,fill="#dbe8df",outline="#4b3522")
    for wx in (x+w*.18,x+w*.78):
        cv.create_oval(wx,y-h*.02,wx+w*.13,y+h*.22,fill="#242424",outline="")
    cv.create_text(x+w*.48,y-h*.17,text="BARANGAY",fill="#fff3a1",font=("Arial",int(max(8,11*s)),"bold"))


def draw_bamboo_frame(cv, x, y, w, h, tags=None):
    """Woven-bamboo UI frame inspired by bahay-kubo walls."""
    tag=tags
    cv.create_rectangle(x,y,x+w,y+h,fill="",outline="#6f4e37",width=3,tags=tag)
    for xx in (x+12, x+w-12):
        cv.create_line(xx,y,xx,y+h,fill="#a87943",width=4,tags=tag)
    for yy in (y+12, y+h-12):
        cv.create_line(x,yy,x+w,yy,fill="#c49a5a",width=3,tags=tag)
    for i in range(-h, int(w), 18):
        cv.create_line(x+i,y,x+i+h,y+h,fill="#d2ad6c",width=1,tags=tag)
        cv.create_line(x+i,y+h,x+i+h,y,fill="#b7894d",width=1,tags=tag)

def draw_sari_sari(cv, x, y, s=1.0, tags=None):
    """Tiny sari-sari store for the neighborhood backdrop."""
    w,h=190*s,110*s
    cv.create_polygon(x,y+22*s,x+w*.5,y-18*s,x+w,y+22*s,
                      fill="#7a4930",outline="#4b2e1f",width=2,tags=tags)
    cv.create_rectangle(x+14*s,y+22*s,x+w-14*s,y+h,
                        fill="#d6bd7c",outline="#6f4e37",width=2,tags=tags)
    cv.create_rectangle(x+30*s,y+42*s,x+w-30*s,y+h-12*s,
                        fill="#f5ead0",outline="#6f4e37",width=2,tags=tags)
    cv.create_rectangle(x+22*s,y+34*s,x+w-22*s,y+48*s,
                        fill="#b52b3a",outline="",tags=tags)
    cv.create_text(x+w*.5,y+41*s,text="SARI-SARI",fill="#fff5cf",
                   font=("Arial",max(6,int(10*s)),"bold"),tags=tags)
    for i,col in enumerate(["#e5c24e","#4b9b72","#d66b58","#78a8c7","#b36bb3"]):
        xx=x+(42+i*22)*s
        cv.create_rectangle(xx,y+58*s,xx+15*s,y+78*s,fill=col,outline="#6f4e37",tags=tags)
    cv.create_text(x+w*.5,y+h-4*s,text="TINGI • MALIIT • TIPID",
                   fill="#6f4e37",font=("Arial",max(5,int(7*s)),"bold"),tags=tags)

def draw_ricefield(cv, x, y, w, h, tags=None):
    cv.create_rectangle(x,y,x+w,y+h,fill="#a9c86b",outline="",tags=tags)
    for yy in range(int(y+8),int(y+h),12):
        cv.create_line(x,yy,x+w,yy,fill="#88ad57",width=1,tags=tags)
    for xx in range(int(x+12),int(x+w),22):
        cv.create_line(xx,y+h,xx-5,y+h-16,fill="#668e45",width=2,tags=tags)

def draw_mountain(cv, x, y, s=1.0, tags=None):
    pts=[x,y+80*s,x+75*s,y-10*s,x+145*s,y+80*s]
    cv.create_polygon(pts,fill="#6f8f61",outline="#55724d",width=2,tags=tags)
    cv.create_polygon([x+75*s,y-10*s,x+52*s,y+28*s,x+98*s,y+28*s],
                      fill="#dce9b4",outline="",tags=tags)

def draw_basket_pattern(cv, x, y, w, h, tags=None):
    for yy in range(int(y),int(y+h),16):
        cv.create_line(x,yy,x+w,yy,fill="#ead8a8",width=1,tags=tags)
    for xx in range(int(x),int(x+w),16):
        cv.create_line(xx,y,xx,y+h,fill="#ead8a8",width=1,tags=tags)

def draw_game_chrome():
    """Decorative Filipino chrome that stays outside the primary HUD/footer."""
    t = current_theme()
    accent = t["accent"]

    # A slim title strip sits below the main HUD, so it never paints over
    # the status cards. The playable board starts below this strip.
    strip_y1, strip_y2 = 76, 108
    main_cv.create_rectangle(18, strip_y1, SW-18, strip_y2,
                             fill="#f7edcf", outline="#6f4e37", width=2, tags="ui")
    draw_parol(main_cv, 38, (strip_y1+strip_y2)/2, 10, accent, tags="ui")
    main_cv.create_text(58, (strip_y1+strip_y2)/2,
                        text=f"BARANGAY • {area_name()}", anchor="w",
                        fill=accent, font=("Georgia", 12, "bold"), tags="ui")
    main_cv.create_text(SW-38, (strip_y1+strip_y2)/2,
                        text="WASD / ARROWS  •  SPACE = SIPA  •  ESC = PAUSE",
                        anchor="e", fill="#6b4e2f", font=("Arial", 8, "bold"), tags="ui")

    # Compact mission card sits to the left of the maze when there is room.
    bx = GAME_X0 - 185
    by = GAME_Y0 + 6
    if bx > 12:
        main_cv.create_rectangle(bx, by, bx+168, by+168,
                                 fill="#f7edcf", outline="#6f4e37", width=2, tags="ui")
        main_cv.create_text(bx+84, by+22, text="MISSION",
                            fill=accent, font=("Georgia", 12, "bold"), tags="ui")
        main_cv.create_text(bx+84, by+54,
                            text=f"SUSI {keys_collected}/{keys_required}",
                            fill="#a16d22", font=("Georgia", 15, "bold"), tags="ui")
        main_cv.create_text(bx+14, by+84, text=objective, anchor="w", width=140,
                            fill="#5e452c", font=("Arial", 8, "bold"), tags="ui")
        event_text = "WALANG SIDE EVENT"
        if mission_event == "missing_key":
            event_text = "EVENT: NATATAGONG SUSI"
        elif mission_event == "delivery":
            event_text = "EVENT: SUPPLY"
        main_cv.create_text(bx+14, by+128, text=event_text,
                            anchor="w", fill="#7a5b35", font=("Arial", 7, "bold"), tags="ui")

def draw_floaters(my_gen):
    global anim_job, tick_frame, floaters
    if my_gen != screen_gen:
        return
    tick_frame += 1
    main_cv.delete("lobby_anim")
    t=current_theme()
    draw_banderitas(main_cv, 32, current_theme()["accent"], tags="lobby_anim")
    for f in floaters:
        f["y"] += f["vy"]
        f["x"] += math.sin((tick_frame+f["phase"])/18)*0.7
        if f["y"] < -50: f["y"] = SH+30
        if f["y"] > SH+50: f["y"] = -30
        if f["kind"]=="star": draw_parol(main_cv,f["x"],f["y"],f["r"],f["color"],tags="lobby_anim")
        elif f["kind"]=="leaf":
            main_cv.create_oval(f["x"],f["y"],f["x"]+f["r"]*1.7,f["y"]+f["r"],fill=f["color"],outline="",tags="lobby_anim")
        elif f["kind"]=="cloud": draw_cloud(main_cv,f["x"],f["y"],f["r"]/35,fill="#fff8df",tags="lobby_anim")
    main_cv.create_text(80,SH-35,text="🇵🇭  LARO NG BARANGAY  •  MISYON • DISKARTE • TAKAS",anchor="w",fill="#fff8df",font=("Arial",11,"bold"),tags="lobby_anim")
    anim_job=root.after(70,lambda:draw_floaters(my_gen))

def lobby():
    clear()
    global floaters, anim_job
    my_gen=screen_gen
    t=current_theme()
    # Full Filipino neighborhood backdrop
    draw_theme_background()
    draw_banderitas(main_cv, 30, t["accent"], tags="theme")
    # Large centered woven-bamboo panel
    panel_w=min(1040,SW-260); panel_h=min(650,SH-120)
    px=(SW-panel_w)/2; py=(SH-panel_h)/2+22
    main_cv.create_rectangle(px+10,py+12,px+panel_w+10,py+panel_h+12,
                             fill="#5b4630",outline="",tags="ui")
    main_cv.create_rectangle(px,py,px+panel_w,py+panel_h,
                             fill="#f7edcf",outline="#6f4e37",width=4,tags="ui")
    draw_bamboo_frame(main_cv,px+16,py+16,panel_w-32,panel_h-32,tags="ui")
    # Header
    draw_parol(main_cv,px+72,py+70,30,t["accent"],tags="ui")
    draw_parol(main_cv,px+panel_w-72,py+70,30,t["accent"],tags="ui")
    main_cv.create_text(SW/2,py+55,text="MISSION: TUMAKAS",
                        fill="#4b3522",font=("Georgia",42,"bold"),tags="ui")
    main_cv.create_text(SW/2,py+52,text="MISSION: TUMAKAS",
                        fill=t["accent"],font=("Georgia",42,"bold"),tags="ui")
    main_cv.create_text(SW/2,py+91,text="ISANG MAKULAY NA BARANGAY ADVENTURE",
                        fill="#6b4e2f",font=("Arial",12,"bold"),tags="ui")
    main_cv.create_text(SW/2,py+111,text="MISYON • DISKARTE • KULTURA • TAKAS",
                        fill="#a16d22",font=("Arial",8,"bold"),tags="ui")
    # Three stat cards
    cards=[("ANTAS",str(level),t["accent"]),("PUNTOS",str(points),"#a16d22"),
           ("LUGAR",area_name(),"#2f6f73")]
    for i,(lab,val,col) in enumerate(cards):
        cx=px+80+i*185
        cy=py+142
        main_cv.create_rectangle(cx,cy,cx+160,cy+78,fill="#fff8df",outline="#caa66a",width=2,tags="ui")
        main_cv.create_text(cx+80,cy+22,text=lab,fill="#7a5b35",font=("Arial",9,"bold"),tags="ui")
        main_cv.create_text(cx+80,cy+51,text=val,fill=col,font=("Georgia",18,"bold"),tags="ui")
    draw_mini_character(main_cv,px+panel_w-120,py+180,30,get_color(),math.sin(tick_frame/8)*2)
    main_cv.create_text(px+panel_w-120,py+225,text="IYONG TAUHAN",fill="#6b4e2f",
                        font=("Arial",8,"bold"),tags="ui")
    # Feature cards around the controls
    feature_y=py+245
    features=[("🏠","BAHAY KUBO","Mga bahay ang bumubuo sa maze"),
              ("🏪","SARI-SARI STORE","Bili ng tulong gamit ang puntos"),
              ("🛺","BARANGAY ROAD","Iwasan ang tricycle at kalesa")]
    for i,(ico,title,desc) in enumerate(features):
        cx=px+70+i*290
        main_cv.create_rectangle(cx,feature_y,cx+260,feature_y+70,fill="#efe0b5",
                                 outline="#caa66a",width=1,tags="ui")
        main_cv.create_text(cx+25,feature_y+22,text=ico,font=("Arial",15),tags="ui")
        main_cv.create_text(cx+50,feature_y+18,text=title,anchor="w",
                            fill=t["accent"],font=("Arial",9,"bold"),tags="ui")
        main_cv.create_text(cx+50,feature_y+43,text=desc,anchor="w",
                            fill="#6b4e2f",font=("Arial",7,"bold"),tags="ui")
    # Custom menu controls: all three actions are separated so none can
    # overlap the theme selector or be hidden by another widget.
    btn_frame=tk.Frame(root,bg="#f7edcf",highlightthickness=0)
    btn_frame.place(x=px+panel_w*.19,y=py+325,width=panel_w*.62,height=166)
    styled_button(btn_frame,"SIMULAN ANG MISSION",start,fg=t["accent"],w=24,h=46,font_size=11).pack(pady=3,fill="x")
    styled_button(btn_frame,"SARI-SARI STORE",sari_sari_store,fg="#2f6f73",w=24,h=46,font_size=11).pack(pady=3,fill="x")
    styled_button(btn_frame,"TINDAHAN NG KASUOTAN",shop,fg="#8b6339",w=24,h=46,font_size=11).pack(pady=3,fill="x")

    # Theme selector sits in its own row below the action buttons.
    theme_frame=tk.Frame(root,bg="#ead7a2",bd=1,relief="solid")
    theme_frame.place(x=px+panel_w*.19,y=py+505,width=panel_w*.62,height=44)
    tk.Label(theme_frame,text=f"TANAWIN: {theme_name}",fg="#5d432b",bg="#ead7a2",
             font=("Georgia",9,"bold")).pack(side="left",padx=8)
    for name in THEMES:
        styled_button(theme_frame, name, lambda n=name: set_theme(n),
                      fg="#4b3522", w=11, h=30, font_size=7).pack(
                          side="left", expand=True, fill="x", padx=3, pady=7)

    main_cv.create_text(SW/2,py+560,
                        text="WASD / ARROWS  •  SPACE: SIPA  •  ESC: PAUSE",
                        fill="#5d432b",font=("Arial",9,"bold"),tags="ui")
    main_cv.create_text(SW/2,py+582,
                        text="KUNIN ANG MGA SUSI • KAUSAPIN ANG MGA TAGA-BARANGAY • HANAPIN ANG LABAS",
                        fill=t["accent"],font=("Arial",9,"bold"),tags="ui")
    if level in best_times:
        main_cv.create_text(SW/2,py+604,text=f"PINAKAMABILIS SA ANTAS {level}: {best_times[level]:.1f}s",
                            fill="#6b4e2f",font=("Arial",8,"bold"),tags="ui")
    # Floating cultural decorations
    floaters=[
        {"kind":"star","x":SW*.12,"y":SH*.30,"r":18,"vy":-0.22,"phase":2,"color":"#f0c83d"},
        {"kind":"star","x":SW*.88,"y":SH*.48,"r":15,"vy":0.16,"phase":9,"color":t["accent"]},
        {"kind":"leaf","x":SW*.25,"y":SH*.18,"r":10,"vy":0.28,"phase":5,"color":"#4e8b48"},
        {"kind":"leaf","x":SW*.72,"y":SH*.28,"r":12,"vy":-0.14,"phase":14,"color":"#5b934e"},
        {"kind":"cloud","x":SW*.46,"y":SH*.08,"r":28,"vy":0.07,"phase":7,"color":"#fff8df"},
    ]
    draw_floaters(my_gen)
    refresh_bgm()

def set_theme(name):
    global theme_name
    if name in THEMES:
        theme_name = name
        save()
        lobby()

def animate_lobby(my_gen):
    global anim_job, tick_frame
    if my_gen != screen_gen:
        return
    tick_frame += 1
    # The lobby itself is intentionally mostly static; only parol glow/floaters
    # animate so low-end machines do not waste CPU repainting the whole screen.
    main_cv.delete("lobby_anim")
    t = current_theme()
    pulse = 1 + 0.08 * math.sin(tick_frame / 8)
    draw_parol(main_cv, 75, 85, 26*pulse, t["accent"])
    anim_job = root.after(80, lambda: animate_lobby(my_gen))

def animate_title(title_cv, my_gen):
    if my_gen != screen_gen:
        return
    try:
        title_cv.delete("all")
        pulse = 1 + 0.04*math.sin(tick_frame/10)
        fsize = max(1, int(39*pulse))
        col = current_theme()["accent"]
        title_cv.create_text(300, 49, text="MISSION: TUMAKAS", fill="#4b3522",
                             font=("Georgia", fsize, "bold"))
        title_cv.create_text(298, 46, text="MISSION: TUMAKAS", fill=col,
                             font=("Georgia", fsize, "bold"))
        title_cv.create_text(300, 82, text="LARO NG BARANGAY", fill="#6b4e2f",
                             font=("Arial", 10, "bold"))
        draw_bahay_kubo(title_cv, 530, 50, 0.25)
        root.after(80, lambda: animate_title(title_cv, my_gen))
    except tk.TclError:
        pass

# ================= GAMEPLAY SCREEN =================

def start():
    clear()
    global trail, lives, in_game, paused, level_start_time, combo, combo_timer
    global night_mode, boss_level, boss
    my_gen = screen_gen
    in_game = True
    paused = False
    level_start_time = time.monotonic()
    trail = []
    lives = 3
    combo = 0
    combo_timer = 0
    night_mode = (level % 4 == 0 or area_name() == "LUMANG BARANGAY")
    boss_level = (level % 10 == 0)
    boss = None

    # Compact on-screen controls: every important keyboard action also has a
    # visible game button, so players do not have to memorize shortcuts.
    game_controls = tk.Frame(root, bg="#f7edcf", bd=0, highlightthickness=1, highlightbackground="#6f4e37")
    game_controls.place(relx=1.0, x=-24, y=16, anchor="ne")
    styled_button(game_controls, "HOME", go_home, fg="#8d2f2f", w=8, h=34, font_size=8).pack(side="left", padx=2, pady=2)
    styled_button(game_controls, "ESC • PAUSE", toggle_pause, fg="#6f4e37", w=12, h=34, font_size=8).pack(side="left", padx=2, pady=2)
    styled_button(game_controls, "RESTART", restart_level, fg="#a16d22", w=10, h=34, font_size=8).pack(side="left", padx=2, pady=2)
    styled_button(game_controls, "HELP", show_help, fg="#5d6f3a", w=7, h=34, font_size=8).pack(side="left", padx=2, pady=2)

    root.unbind("<Button-1>")
    root.bind("<KeyPress>", move)
    root.bind("<Escape>", toggle_pause)
    root.bind("<Home>", go_home)
    root.bind("<r>", restart_level)
    root.bind("<R>", restart_level)
    root.bind("<h>", show_help)
    root.bind("<H>", show_help)
    root.bind("<space>", lambda e: shoot())
    create_maze(my_gen)
    refresh_bgm()

def create_maze(my_gen):
    global maze, player, exit_pos, cell, trail, GAME_X0, GAME_SIZE
    global enemies, items, ammo, speed_boost, shield, move_count, enemy_tick
    global keys, keys_collected, keys_required, explored
    global npcs, vehicles, shortcuts, objective, mission_event, event_done, boss

    # Medium barangay board: gameplay stays fullscreen, but the maze itself
    # is deliberately compact so the player can see the whole neighborhood
    # and the decorative Filipino environment around it.
    cols, rows = 33, 21
    size = min(rows, cols)  # compatibility for a few old loops
    maze_rows, maze_cols = rows, cols
    cell = min(GAME_W / maze_cols, GAME_H / maze_rows)
    board_w, board_h = cell * maze_cols, cell * maze_rows
    board_x0 = (SW-board_w)/2
    board_y0 = GAME_Y0
    GAME_X0 = int(board_x0)
    GAME_SIZE = int(board_w)
    maze = [[1] * maze_cols for _ in range(maze_rows)]
    maze[1][1] = 0

    def carve(r, c):
        d = [(2,0), (-2,0), (0,2), (0,-2)]
        random.shuffle(d)

        for dr, dc in d:
            nr, nc = r + dr, c + dc

            if 1 <= nr < maze_rows-1 and 1 <= nc < maze_cols-1 and maze[nr][nc]:
                maze[r+dr//2][c+dc//2] = 0
                maze[nr][nc] = 0
                carve(nr, nc)

    carve(1, 1)

    # ---------- BRAID THE MAZE (open extra walls) ----------
    # A "perfect" maze only has ONE path between any two points. We knock
    # down a SMALL number of extra walls so a couple of alternate routes
    # and escape loops exist (so you're never 100% trapped by an enemy),
    # but keep it low so the maze is still a real, tricky maze rather than
    # an open room. This got dialed way down from earlier -- it used to
    # braid 35-65% of eligible walls, which made mazes trivially easy.
    braid_chance = max(0.04, 0.16 - level * 0.0015)
    for r in range(2, maze_rows - 2):
        for c in range(2, maze_cols - 2):
            if maze[r][c] == 1 and random.random() < braid_chance:
                if r % 2 == 1 and maze[r][c-1] == 0 and maze[r][c+1] == 0:
                    maze[r][c] = 0
                elif c % 2 == 1 and maze[r-1][c] == 0 and maze[r+1][c] == 0:
                    maze[r][c] = 0

    # ---------- BARANGAY BLOCK DETAILS ----------
    # Add a few wider road gaps so the maze feels like connected house lots
    # instead of a purely abstract labyrinth.
    for rr in range(3, maze_rows-2, 6):
        for cc in range(2, maze_cols-2):
            if random.random() < 0.72:
                maze[rr][cc] = 0
    for cc in range(4, maze_cols-2, 6):
        for rr in range(2, maze_rows-2):
            if random.random() < 0.55:
                maze[rr][cc] = 0

    player = [1, 1]
    exit_pos = [maze_rows-2, maze_cols-2]
    maze[-2][-2] = 0
    trail = []
    move_count = 0
    keys_collected = 0
    keys_required = min(3, max(2, 1 + level // 12))
    explored = {(1, 1)}

    # ---------- REACHABILITY FLOOD-FILL ----------
    # BUGFIX: the "wider road gaps" pass just above pokes extra holes at
    # fixed grid coordinates to make roads feel wider. One of those two
    # loops opens cells on even columns with an UNRESTRICTED row range,
    # which can land on a true grid "post" (even row, even col) that the
    # actual maze-carving algorithm never touches or connects to anything
    # -- creating a tiny pocket that is open (maze[r][c] == 0) but sealed
    # off on all four sides from the rest of the maze.
    #
    # Every spawn pool below used to be built by scanning for
    # "maze[r][c] == 0" with NO check that the tile was actually reachable
    # from the player's start. If a SUSI (key), item, NPC, or enemy landed
    # in one of these sealed pockets, it became permanently uncollectable
    # -- exactly the "susi can't be found" / "only one key shows up" bug,
    # since a level needs 2-3 keys and any of them stranded like this
    # makes the level impossible to finish.
    #
    # Fix: flood-fill from the player's start first, and only ever spawn
    # things on tiles that are genuinely reachable.
    reachable = {(1, 1)}
    frontier = deque([(1, 1)])
    while frontier:
        r, c = frontier.popleft()
        for dr, dc in ((-1,0),(1,0),(0,-1),(0,1)):
            nr, nc = r+dr, c+dc
            if (0 <= nr < maze_rows and 0 <= nc < maze_cols
                    and maze[nr][nc] == 0 and (nr, nc) not in reachable):
                reachable.add((nr, nc))
                frontier.append((nr, nc))

    # Belt-and-suspenders: carve() itself should always connect the exit
    # (it's a full spanning tree over every odd/odd cell in bounds), but
    # if that ever changes, force a straight-line corridor through to it
    # rather than ever generating an unwinnable level.
    if tuple(exit_pos) not in reachable:
        r, c = 1, 1
        er, ec = exit_pos
        while (r, c) != (er, ec):
            if c != ec:
                c += 1 if ec > c else -1
            elif r != er:
                r += 1 if er > r else -1
            maze[r][c] = 0
            if (r, c) not in reachable:
                reachable.add((r, c))
                frontier.append((r, c))
        while frontier:
            r, c = frontier.popleft()
            for dr, dc in ((-1,0),(1,0),(0,-1),(0,1)):
                nr, nc = r+dr, c+dc
                if (0 <= nr < maze_rows and 0 <= nc < maze_cols
                        and maze[nr][nc] == 0 and (nr, nc) not in reachable):
                    reachable.add((nr, nc))
                    frontier.append((nr, nc))

    objectives = [
        "KUNIN ANG MGA SUSI AT TAKAS",
        "HANAPIN ANG DAAN SA PALENGKE",
        "KUMUHA NG SUPPLIES BAGO TUMAKAS",
        "HANAPIN ANG NAWAWALANG SUSI",
    ]
    objective = objectives[(level-1) % len(objectives)]
    mission_event = "missing_key" if level % 7 == 0 else ("delivery" if level % 5 == 0 else None)
    event_done = False

    # ---------- ENEMIES ----------
    enemy_count = min(1 + level // 4, 8)
    # BUGFIX: was `[(r,c) for r in range(maze_rows) for c in range(maze_cols)
    # if maze[r][c] == 0 ...]` -- a plain scan with no reachability check.
    # Now restricted to the flood-filled `reachable` set above.
    open_cells = [p for p in reachable if p not in [(1, 1), tuple(exit_pos)]]
    random.shuffle(open_cells)
    safe_cells = [p for p in open_cells
                  if abs(p[0]-1) + abs(p[1]-1) >= 4
                  and abs(p[0]-exit_pos[0]) + abs(p[1]-exit_pos[1]) >= 2]
    enemies = []
    for p in safe_cells[:enemy_count]:
        kind = random.choice(ENEMY_KINDS)
        enemies.append({
            "pos": list(p),
            "kind": kind,
            "hp": ENEMY_STATS[kind]["hp"],
            # random starting offset so same-kind enemies don't all step
            # in perfect lockstep
            "timer": random.randint(0, 2),
        })
    enemy_tick = max(1, 3 - level // 25)

    # ---------- RANDOM REWARD BOXES ----------
    box_count = max(2, min(5, size // 5))
    # BUGFIX: this used to be `open_cells[enemy_count:]`, which just drops
    # the first N cells of the shuffled list. But enemies are actually
    # placed from `safe_cells` (a *different*, filtered ordering), so that
    # slice didn't line up with the real enemy tiles at all -- it silently
    # threw away N unrelated candidate cells while doing nothing to stop
    # keys/items/NPCs/vehicles from spawning right on top of an enemy's
    # starting square. Excluding the actual enemy positions fixes both.
    enemy_positions = {tuple(e["pos"]) for e in enemies}
    remaining = [p for p in open_cells if p not in enemy_positions]
    random.shuffle(remaining)
    # ---------- ESCAPE KEYS ----------
    # Keys turn the maze into a small mission instead of simply walking to
    # the exit. They are placed away from spawn and exit so exploration is
    # required.
    key_pool = [p for p in remaining if abs(p[0]-1) + abs(p[1]-1) >= 6
                and abs(p[0]-exit_pos[0]) + abs(p[1]-exit_pos[1]) >= 4]
    random.shuffle(key_pool)
    # Safety net: with the reachability fix above this should no longer
    # happen, but if the distance-filtered pool is ever smaller than
    # keys_required for some future maze tweak, cap the requirement to
    # what actually got placed (down to 0) rather than generating a
    # level that can never be finished.
    keys_required = min(keys_required, len(key_pool))
    keys = {pos: True for pos in key_pool[:keys_required]}

    items = {}
    item_pool = [p for p in remaining if p not in keys]
    random.shuffle(item_pool)
    for pos in item_pool[:box_count]:
        items[pos] = random.choice(ITEM_TYPES)

    ammo, speed_boost, shield = 0, 0, 0

    # BUGFIX (round 2): npc_pool / vehicle_pool / shortcut_pool were each
    # built straight from open_cells, filtered only against keys/items/
    # exit -- never against each other, and never against the enemies'
    # actual tiles either. So an NPC could spawn on a vehicle's square,
    # a shortcut on an NPC's square, any of them on an enemy's square,
    # etc. `occupied` now accumulates every tile already claimed so far
    # and each pool is filtered against it before its own picks are
    # added in turn.
    occupied = set(keys) | set(items) | enemy_positions

    # ---------- NPC HINTS ----------
    npcs = []
    npc_pool = [p for p in open_cells if p not in occupied and p != tuple(exit_pos)]
    random.shuffle(npc_pool)
    chosen_npcs = npc_pool[:min(3, 1 + level//25)]
    occupied.update(chosen_npcs)
    for p in chosen_npcs:
        npcs.append({"pos": list(p), "hint": random.choice([
            "Hanapin ang susi sa kabilang kanto!",
            "May shortcut sa likod ng bahay.",
            "Mag-ingat sa mga sasakyan sa kalsada.",
            "Sari-sari store: puwedeng bumili ng tulong!"
        ])})

    # ---------- TRICYCLE / KALESA OBSTACLES ----------
    vehicles = []
    vehicle_pool = [p for p in open_cells if p not in occupied and p != tuple(exit_pos)]
    random.shuffle(vehicle_pool)
    chosen_vehicles = vehicle_pool[:min(3, 1 + level//18)]
    occupied.update(chosen_vehicles)
    for p in chosen_vehicles:
        vehicles.append({"pos": list(p), "kind": random.choice(["tricycle", "kalesa"]), "timer": random.randint(0,5)})

    # ---------- HIDDEN HOUSE SHORTCUTS ----------
    shortcuts = {}
    shortcut_pool = [p for p in open_cells if p not in occupied and p != tuple(exit_pos)]
    random.shuffle(shortcut_pool)
    for p in shortcut_pool[:min(2, 1 + level//30)]:
        r,c = p
        # BUGFIX (round 2): candidate destinations were never checked
        # against keys/items/exit, so a shortcut could warp the player
        # straight onto a key or box tile. Landing there doesn't trigger
        # a pickup (collect_key/collect_item already ran earlier in that
        # same move()), so the key/item became permanently uncollectable
        # unless the player happened to step off and back on. Filtered
        # out here, and move() now also re-checks pickups right after a
        # shortcut jump as a safety net.
        candidates = [(r+dr,c+dc) for dr,dc in ((0,4),(0,-4),(4,0),(-4,0))
                     if 0 <= r+dr < maze_rows and 0 <= c+dc < maze_cols
                     and maze[r+dr][c+dc] == 0
                     and (r+dr,c+dc) not in keys and (r+dr,c+dc) not in items
                     and (r+dr,c+dc) != tuple(exit_pos)]
        if candidates:
            shortcuts[p] = random.choice(candidates)

    # ---------- BOSS / CHASE LEVEL ----------
    if boss_level:
        far = max(open_cells, key=lambda p: abs(p[0]-1)+abs(p[1]-1)) if open_cells else (size-2,size-2)
        boss = {"pos": list(far), "hp": 6 + level//10, "timer": 0}
        objective = "BOSS LEVEL: TALUNIN ANG HEPE NG BARANGAY"
    else:
        boss = None

    draw()
    animate_maze(my_gen)

def get_color():
    if skin == "white":
        return "#e8e8e8"

    if skin == "bahaghari":
        return random.choice(["#b52b3a", "#d49b2a", "#5e8f45", "#2f7d9a", "#7c5aa6"])

    return skins[skin][1]

# ---------- CHARACTER DRAWING ----------

def draw_player(x, y, c):
    """Friendly hand-drawn human barangay runner, with Filipino-inspired
    shirt colors and a tiny woven hat/hat-band detail."""
    cx, cy = x + cell/2, y + cell/2
    scale = max(0.65, min(1.35, cell/28))
    skin_col = "#c98a5b"
    hair = "#2b1a12"
    shirt = c if c != "chroma" else random.choice(["#b52b3a", "#d49b2a", "#2f7d6d", "#4d6fb3", "#7c5aa6"])
    bob = math.sin(tick_frame/5) * cell*.035
    cy += bob
    r = cell*.42
    if shield > 0:
        pulse = 3 + math.sin(tick_frame/4)
        main_cv.create_oval(cx-r-pulse, cy-r-pulse, cx+r+pulse, cy+r+pulse,
                            outline="#f7d24b", width=2, tags="game")
    # shadow
    main_cv.create_oval(cx-r*.65, cy+r*.65, cx+r*.65, cy+r*.88, fill="#5b4630", outline="", tags="game")
    # legs and shoes
    main_cv.create_rectangle(cx-r*.25, cy+r*.05, cx-r*.04, cy+r*.65, fill="#315d79", outline="#1f3342", tags="game")
    main_cv.create_rectangle(cx+r*.04, cy+r*.05, cx+r*.25, cy+r*.65, fill="#315d79", outline="#1f3342", tags="game")
    main_cv.create_oval(cx-r*.34, cy+r*.55, cx-r*.01, cy+r*.78, fill="#272727", outline="", tags="game")
    main_cv.create_oval(cx+r*.01, cy+r*.55, cx+r*.34, cy+r*.78, fill="#272727", outline="", tags="game")
    # body
    main_cv.create_rectangle(cx-r*.42, cy-r*.20, cx+r*.42, cy+r*.30, fill=shirt, outline="#4a241f", width=1, tags="game")
    # simple woven diagonal sash
    main_cv.create_line(cx-r*.35, cy-r*.12, cx+r*.34, cy+r*.24, fill="#f0c83d", width=max(1,int(cell*.055)), tags="game")
    # arms
    main_cv.create_oval(cx-r*.60, cy-r*.12, cx-r*.32, cy+r*.28, fill=shirt, outline="#4a241f", tags="game")
    main_cv.create_oval(cx+r*.32, cy-r*.12, cx+r*.60, cy+r*.28, fill=shirt, outline="#4a241f", tags="game")
    # neck/head
    main_cv.create_rectangle(cx-r*.14, cy-r*.34, cx+r*.14, cy-r*.16, fill=skin_col, outline="", tags="game")
    main_cv.create_oval(cx-r*.40, cy-r*.86, cx+r*.40, cy-r*.20, fill=skin_col, outline="#6f4e37", width=1, tags="game")
    # hair
    main_cv.create_arc(cx-r*.43, cy-r*.95, cx+r*.43, cy-r*.23, start=180, extent=180, fill=hair, outline=hair, tags="game")
    # little salakot-inspired brim
    main_cv.create_oval(cx-r*.53, cy-r*.90, cx+r*.53, cy-r*.72, fill="#c59b55", outline="#6f4e37", width=1, tags="game")
    main_cv.create_arc(cx-r*.38, cy-r*.97, cx+r*.38, cy-r*.48, start=180, extent=180, fill="#c59b55", outline="#6f4e37", tags="game")
    # eyes
    main_cv.create_oval(cx-r*.20, cy-r*.57, cx-r*.12, cy-r*.48, fill="#111", outline="", tags="game")
    main_cv.create_oval(cx+r*.12, cy-r*.57, cx+r*.20, cy-r*.48, fill="#111", outline="", tags="game")

def draw_enemy(x, y, kind, hp=1):
    cx, cy = x + cell/2, y + cell/2
    r = cell/2 - 6
    light, dark = ENEMY_PALETTE[kind]
    bob = math.sin(tick_frame/6 + x*0.1) * 2

    if kind == "ghost":
        cy += bob
        pts = [cx-r, cy+r*0.4, cx-r, cy-r*0.3]
        # rounded top via oval + jagged bottom via polygon
        main_cv.create_oval(cx-r, cy-r, cx+r, cy+r*0.5, fill=light, outline=dark, width=2)
        zig = []
        n = 4
        for i in range(n+1):
            px = cx - r + (2*r)*(i/n)
            py = cy + r*0.5 + (r*0.5 if i % 2 == 0 else 0)
            zig.append((px, py))
        poly = [(cx-r, cy)] + zig + [(cx+r, cy)]
        flat = [v for pt in poly for v in pt]
        main_cv.create_polygon(flat, fill=light, outline=dark, width=2, smooth=False)
        main_cv.create_oval(cx-r*0.5, cy-r*0.2, cx-r*0.15, cy+r*0.15, fill="white")
        main_cv.create_oval(cx+r*0.15, cy-r*0.2, cx+r*0.5, cy+r*0.15, fill="white")
        main_cv.create_oval(cx-r*0.38, cy-r*0.05, cx-r*0.22, cy+r*0.1, fill="black")
        main_cv.create_oval(cx+r*0.22, cy-r*0.05, cx+r*0.38, cy+r*0.1, fill="black")

    elif kind == "spike":
        n = 8
        pts = []
        for i in range(n*2):
            ang = math.pi*2*i/(n*2) + tick_frame*0.05
            rad = r if i % 2 == 0 else r*0.45
            pts += [cx + rad*math.cos(ang), cy + rad*math.sin(ang)]
        main_cv.create_polygon(pts, fill=light, outline=dark, width=2)
        main_cv.create_oval(cx-r*0.35, cy-r*0.2, cx-r*0.05, cy+r*0.1, fill="white")
        main_cv.create_oval(cx+r*0.05, cy-r*0.2, cx+r*0.35, cy+r*0.1, fill="white")
        main_cv.create_oval(cx-r*0.25, cy-r*0.1, cx-r*0.12, cy+r*0.02, fill="black")
        main_cv.create_oval(cx+r*0.12, cy-r*0.1, cx+r*0.25, cy+r*0.02, fill="black")

    else:  # blob
        squish = 1 + 0.15*math.sin(tick_frame/5 + x*0.2)
        main_cv.create_oval(cx-r*squish, cy-r/squish, cx+r*squish, cy+r/squish,
                            fill=light, outline=dark, width=2)
        for dx in (-r*0.5, 0, r*0.5):
            drip = 3 + 2*math.sin(tick_frame/5 + dx)
            main_cv.create_oval(cx+dx-3, cy+r/squish-2, cx+dx+3, cy+r/squish+drip,
                                fill=light, outline="")
        main_cv.create_oval(cx-r*0.4, cy-r*0.15, cx-r*0.12, cy+r*0.15, fill="black")
        main_cv.create_oval(cx+r*0.12, cy-r*0.15, cx+r*0.4, cy+r*0.15, fill="black")

    # HP pips above tougher enemies (e.g. blobs need 2 gun hits) so the
    # player can see at a glance how much of a fight one will be.
    if hp > 1:
        pip_w = 6
        start_x = cx - (hp * pip_w) / 2
        for i in range(hp):
            px = start_x + i * pip_w
            main_cv.create_oval(px, cy-r-10, px+pip_w-2, cy-r-4,
                                 fill="#ff3333", outline="#550000")

def draw_house_tile(cv, x, y, cell_size, wall_col, trim_col, r, c, size):
    """Turn maze wall cells into compact Filipino house/building pieces.
    Open cells remain roads, while wall cells visually read as a barangay
    made from nipa roofs, wooden walls, windows, and small doors."""
    pad = max(2, cell_size * 0.08)
    x1, y1 = x + pad, y + pad
    x2, y2 = x + cell_size - pad, y + cell_size - pad
    roof = lerp_color(wall_col, "#9a6b43", 0.25)
    wood = lerp_color(wall_col, "#d2a56e", 0.35)
    cv.create_rectangle(x1, y1 + cell_size*0.22, x2, y2, fill=wood, outline=wall_col, width=1, tags="game")
    cv.create_polygon(x1-1, y1+cell_size*0.27, (x1+x2)/2, y1, x2+1, y1+cell_size*0.27,
                      fill=roof, outline=trim_col, width=1, tags="game")
    # Tiny window/door detail only when there is a road beside this house.
    open_neighbors = []
    for rr, cc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
        if 0 <= rr < len(maze) and 0 <= cc < len(maze[0]) and maze[rr][cc] == 0:
            open_neighbors.append((rr,cc))
    if open_neighbors:
        if cell_size >= 18:
            cv.create_rectangle((x1+x2)/2-2, y2-cell_size*0.22, (x1+x2)/2+2, y2,
                                fill="#5a3926", outline="", tags="game")
            cv.create_rectangle(x1+cell_size*0.20, y1+cell_size*0.31, x1+cell_size*0.34, y1+cell_size*0.44,
                                fill="#e9d58a", outline=wall_col, width=1, tags="game")
            cv.create_rectangle(x2-cell_size*0.34, y1+cell_size*0.31, x2-cell_size*0.20, y1+cell_size*0.44,
                                fill="#e9d58a", outline=wall_col, width=1, tags="game")

def draw():
    # draw() is the sole owner of main_cv's content while in_game is True
    # (nothing else is drawn on it during play), so a full clear is safe
    # and correct -- avoids per-item tagging every single draw call.
    main_cv.delete("all")
    rows, cols = len(maze), len(maze[0])
    ox, oy = GAME_X0, GAME_Y0
    board_w = int(cell * cols)
    board_h = int(cell * rows)

    bgtop, bgbot, wall = theme_colors()
    draw_theme_background()
    # Keep the board area visually distinct from the neighborhood backdrop.
    draw_banderitas(main_cv, 62, current_theme()["accent"])
    # Board shadow and woven-bamboo frame.
    main_cv.create_rectangle(ox+8, oy+10, ox+board_w+8, oy+board_h+10,
                             fill="#5b4630", outline="", tags="game")
    main_cv.create_rectangle(ox, oy, ox+board_w, oy+board_h,
                             fill=current_theme()["floor"], outline="#6f4e37", width=4, tags="game")
    draw_bamboo_frame(main_cv, ox-7, oy-7, board_w+14, board_h+14, tags="game")

    # The maze is a barangay: roads are walkable cells and every blocked
    # cell is rendered as part of a compact Filipino house/building.
    for r in range(rows):
        for c in range(cols):
            x, y = ox + c*cell, oy + r*cell
            if maze[r][c]:
                draw_house_tile(main_cv, x, y, cell, wall, current_theme()["trim"], r, c, max(rows, cols))
            else:
                # road texture / stepping-stone accents
                if (r+c) % 3 == 0:
                    main_cv.create_oval(x+cell*.46, y+cell*.46, x+cell*.54, y+cell*.54,
                                        fill="#bca775", outline="", tags="game")

    # TRAIL: fading glow dots, every skin except WHITE (trail points are
    # already stored in absolute/offset screen coordinates)
    n = len(trail)
    for i, (x, y, col) in enumerate(trail):
        fade = lerp_color(col, bgbot, i / max(n, 1))
        sz = 5 - i*0.4
        main_cv.create_oval(x-sz, y-sz, x+sz, y+sz, fill=fade, outline="", tags="game")

    # REWARD BOXES (pulsing crates)
    pulse = 1 + 0.08*math.sin(tick_frame/6)
    for (r, c), kind in items.items():
        x, y = ox + c*cell, oy + r*cell
        col = ITEM_COLORS[kind]
        cx, cy = x+cell/2, y+cell/2
        half = (cell/2 - 6) * pulse
        main_cv.create_rectangle(cx-half, cy-half, cx+half, cy+half,
                                 fill="#1a0d2e", outline=col, width=2, tags="game")
        main_cv.create_line(cx-half, cy-half, cx+half, cy+half, fill=col, tags="game")
        main_cv.create_line(cx+half, cy-half, cx-half, cy+half, fill=col, tags="game")
        main_cv.create_text(cx, cy, text=ITEM_LABELS[kind],
                            fill=col, font=("Arial", 7, "bold"), tags="game")

    # ESCAPE KEYS
    # BUGFIX / REQUESTED CHANGE: keys used to only render once their tile
    # had been "explored" (walked near), same fog-of-war rule the minimap
    # used. With the minimap gone there's no other way to reveal a key,
    # so a key you hadn't stumbled across yet was effectively invisible.
    # Keys are now always drawn, with a soft pulsing halo so they stand
    # out clearly against the busy barangay scenery from a distance.
    key_pulse = 1 + 0.22*math.sin(tick_frame/6)
    for (kr, kc) in keys:
        x, y = ox + kc*cell, oy + kr*cell
        cx, cy = x+cell/2, y+cell/2
        cvcol = "#f0c83d"
        halo = cell*.34*key_pulse
        main_cv.create_oval(cx-halo, cy-halo, cx+halo, cy+halo,
                            outline="#fff3a1", width=1, tags="game")
        main_cv.create_oval(cx-cell*.24, cy-cell*.24, cx+cell*.24, cy+cell*.24,
                            fill="#fff3a1", outline=cvcol, width=2, tags="game")
        main_cv.create_line(cx, cy-cell*.18, cx, cy+cell*.18, fill="#8a5a16", width=2, tags="game")
        main_cv.create_line(cx, cy, cx+cell*.16, cy, fill="#8a5a16", width=2, tags="game")

    # HIDDEN SHORTCUT MARKERS (subtle house doors)
    for pos, dest in shortcuts.items():
        if pos in explored:
            r,c = pos
            x,y = ox+c*cell, oy+r*cell
            main_cv.create_rectangle(x+cell*.34,y+cell*.62,x+cell*.66,y+cell*.94, fill="#6f4e37", outline="#f0c83d", tags="game")
            main_cv.create_text(x+cell/2,y+cell*.45,text="↪",fill="#f0c83d",font=("Arial",8,"bold"),tags="game")

    # MOVING TRICYCLES / KALESAS
    for v in vehicles:
        r,c=v["pos"]; x,y=ox+c*cell,oy+r*cell
        col="#b52b3a" if v["kind"]=="tricycle" else "#7a4930"
        main_cv.create_rectangle(x+cell*.16,y+cell*.38,x+cell*.84,y+cell*.72,fill=col,outline="#3d1a22",width=2,tags="game")
        main_cv.create_oval(x+cell*.15,y+cell*.66,x+cell*.32,y+cell*.90,fill="#222",outline="",tags="game")
        main_cv.create_oval(x+cell*.68,y+cell*.66,x+cell*.85,y+cell*.90,fill="#222",outline="",tags="game")
        main_cv.create_text(x+cell/2,y+cell*.25,text="TRI" if v["kind"]=="tricycle" else "KAL",fill="#fff3a1",font=("Arial",7,"bold"),tags="game")

    # NPCs
    for n in npcs:
        r,c=n["pos"]; x,y=ox+c*cell,oy+r*cell; cx,cy=x+cell/2,y+cell/2
        main_cv.create_oval(cx-cell*.28,cy-cell*.30,cx+cell*.28,cy+cell*.30,fill="#f1c27d",outline="#6f4e37",width=1,tags="game")
        main_cv.create_arc(cx-cell*.30,cy-cell*.40,cx+cell*.30,cy+cell*.08,start=180,extent=180,fill="#222",outline="#222",tags="game")
        if (r,c) in explored:
            main_cv.create_text(cx, y+cell*.08, text="?", fill="#f0c83d", font=("Arial",8,"bold"), tags="game")
            if abs(r-player[0]) + abs(c-player[1]) <= 1:
                bubble = n["hint"]
                main_cv.create_rectangle(cx-105, y-30, cx+105, y-7, fill="#fff8df", outline="#6f4e37", tags="game")
                main_cv.create_text(cx, y-18, text=bubble, fill="#4b3522", font=("Arial",7,"bold"), tags="game", width=200)

    # BOSS
    if boss:
        r,c=boss["pos"]; x,y=ox+c*cell,oy+r*cell; cx,cy=x+cell/2,y+cell/2
        main_cv.create_oval(cx-cell*.42,cy-cell*.42,cx+cell*.42,cy+cell*.42,fill="#7b1e1e",outline="#f0c83d",width=3,tags="game")
        main_cv.create_text(cx,cy,text="HEPE",fill="#fff3a1",font=("Arial",7,"bold"),tags="game")
        main_cv.create_text(cx, y+cell*.03, text="♥"*max(1,min(8,boss["hp"])), fill="#ff5555", font=("Arial",7), tags="game")

    # ENEMIES
    for e in enemies:
        er, ec = e["pos"]
        x, y = ox + ec*cell, oy + er*cell
        draw_enemy(x, y, e["kind"], e["hp"])

    # SWIRLING EXIT PORTAL
    r, c = exit_pos
    x, y = ox + c*cell, oy + r*cell
    cx, cy = x+cell/2, y+cell/2
    for i, rad in enumerate([cell/2-3, cell/2-9, cell/2-15]):
        ang = tick_frame*4 + i*40
        main_cv.create_arc(cx-rad, cy-rad, cx+rad, cy+rad, start=ang, extent=260,
                           style="arc", outline="white", width=2, tags="game")
    exit_ready = keys_collected >= keys_required and (not boss_level or boss is None)
    exit_label = "LABAS" if exit_ready else "KANDADO"
    exit_fill = "#fff8df" if exit_ready else "#e0ad2f"
    main_cv.create_text(cx, cy, text=exit_label, fill=exit_fill, font=("Arial", 7, "bold"), tags="game")

    # PLAYER
    r, c = player
    x, y = ox + c*cell, oy + r*cell
    draw_player(x, y, get_color())

    # PARTICLE BURSTS (item pickups, gun kills, hits, confetti) drawn on
    # top of everything else so they read clearly against the maze
    update_and_draw_particles(main_cv)

    if celebrating:
        main_cv.create_rectangle(ox, oy, ox+board_w, oy+board_h,
                                  fill="#000000", stipple="gray25", outline="", tags="game")
        pulse = 1 + 0.06*math.sin(tick_frame/3)
        fsize = int(30*pulse)
        ccx, ccy = ox+board_w/2, oy+board_h/2
        main_cv.create_text(ccx+2, ccy+2, text="LEVEL CLEAR!", fill="#000000",
                             font=("Arial Black", fsize, "bold"), tags="game")
        main_cv.create_text(ccx, ccy, text="LEVEL CLEAR!", fill="#00ffe0",
                             font=("Arial Black", fsize, "bold"), tags="game")

    if flash_color and time.monotonic() < flash_until:
        # Timed state, redrawn every frame while active -- see the BUGFIX
        # note in flash_screen() for why this replaced a one-off canvas item.
        main_cv.create_rectangle(ox, oy, ox+board_w, oy+board_h,
                                  fill=flash_color, outline="", stipple="gray50", tags="game")

    if night_mode:
        # A dark blue overlay creates the day/night level variation while
        # keeping the board readable.
        main_cv.create_rectangle(ox,oy,ox+board_w,oy+board_h,fill="#07152d",stipple="gray50",outline="",tags="game")
        pr,pc=player
        px,py=ox+pc*cell+cell/2,oy+pr*cell+cell/2
        main_cv.create_oval(px-cell*2.5,py-cell*2.5,px+cell*2.5,py+cell*2.5,fill="",outline="#f7e7a1",width=2,tags="game")

    draw_hud()
    draw_mission_status()
    draw_game_chrome()

    if paused:
        # Pause overlay is drawn last so it always sits above the maze.
        main_cv.create_rectangle(ox, oy, ox+board_w, oy+board_h,
                                 fill="#3c2b20", stipple="gray50", outline="", tags="game")
        pcx, pcy = ox+board_w/2, oy+board_h/2
        main_cv.create_rectangle(pcx-220, pcy-130, pcx+220, pcy+145,
                                 fill="#f7edcf", outline="#6f4e37", width=4, tags="game")
        draw_parol(main_cv, pcx-175, pcy-88, 18, current_theme()["accent"], tags="game")
        draw_parol(main_cv, pcx+175, pcy-88, 18, current_theme()["accent"], tags="game")
        main_cv.create_text(pcx, pcy-88, text="NAKA-PAUSE", fill=current_theme()["accent"],
                            font=("Georgia", 28, "bold"), tags="game")
        main_cv.create_text(pcx, pcy-48, text="Piliin ang susunod na gagawin", fill="#5d432b",
                            font=("Arial", 10, "bold"), tags="game")
        # Canvas buttons are intentionally simple and functional; they do not
        # depend on native Tk button styling.
        buttons=[("▶  IPAGPATULOY", toggle_pause, current_theme()["accent"]),
                 ("⌂  HOME / LOBBY", go_home, "#8d2f2f"),
                 ("↻  RESTART LEVEL", restart_level, "#a16d22"),
                 (("🔊  SOUND ON" if sound_enabled else "🔇  SOUND OFF"), toggle_sound, "#2f6f73")]
        by=pcy-18
        for label,cmd,col in buttons:
            main_cv.create_rectangle(pcx-150,by,pcx+150,by+34,fill="#2a1730",outline="#caa66a",width=1,tags="game")
            main_cv.create_text(pcx,by+17,text=label,fill=col,font=("Arial",9,"bold"),tags="game")
            by += 42
        # Mouse hit regions are checked by the dedicated pause click handler.
        root.bind("<Button-1>", pause_click)

def pause_click(event):
    if not paused or not in_game:
        return
    rows, cols = len(maze), len(maze[0])
    ox, oy = GAME_X0, GAME_Y0
    board_w = int(cell * cols)
    board_h = int(cell * rows)
    pcx, pcy = ox+board_w/2, oy+board_h/2
    by=pcy-18
    if pcx-150 <= event.x <= pcx+150:
        if by <= event.y <= by+34:
            toggle_pause(); return
        by += 42
        if by <= event.y <= by+34:
            go_home(); return
        by += 42
        if by <= event.y <= by+34:
            restart_level(); return
        by += 42
        if by <= event.y <= by+34:
            toggle_sound(); draw(); return

def draw_hud():
    # Floating glassy HUD rather than a separate button strip.
    x0,y0=24,12
    w=SW-48
    main_cv.create_rectangle(x0+4,y0+4,x0+w+4,y0+HUD_H+4,fill="#3d1a22",stipple="gray25",outline="",tags="game")
    main_cv.create_rectangle(x0,y0,x0+w,y0+HUD_H,fill="#f7edcf",outline="#6f4e37",width=2,tags="game")
    main_cv.create_text(x0+18,y0+18,text=f"MISSION: TUMAKAS  •  {area_name()}",anchor="w",fill=current_theme()["accent"],font=("Georgia",16,"bold"),tags="game")
    elapsed = max(0, int(time.monotonic() - level_start_time)) if level_start_time else 0
    main_cv.create_text(x0+18,y0+42,text=f"ANTAS {level}   •   PUNTOS {points}   •   BUHAY {lives}   •   ORAS {elapsed:02d}s",anchor="w",fill="#5d432b",font=("Arial",10,"bold"),tags="game")
    x=x0+w-520
    chips=[(f"🔑 {keys_collected}/{keys_required}","#a16d22"),(f"🎒 SIPA {ammo}","#8d3c2f"),(f"⚡ {speed_boost}" if speed_boost>0 else "⚡ —","#2f6f73"),(f"🛡 {shield}" if shield>0 else "🛡 —","#8a6a20"),(f"🔥 x{combo}" if combo>1 else "🔥 —","#b52b3a")]
    for txt,col in chips:
        tw=max(62,len(txt)*8+16)
        main_cv.create_rectangle(x,y0+11,x+tw,y0+45,fill="#fff8df",outline="#caa66a",tags="game")
        main_cv.create_text(x+tw/2,y0+28,text=txt,fill=col,font=("Arial",9,"bold"),tags="game")
        x+=tw+7

def draw_mission_status():
    text=f"{area_name()}  •  {objective}"
    if mission_event == "missing_key" and not event_done:
        text += "  •  EVENT: HANAPIN ANG NATATAGONG SUSI"
    elif mission_event == "delivery" and not event_done:
        text += "  •  EVENT: IHATID ANG SUPPLY"
    if keys_collected < keys_required and "BOSS" not in objective:
        text += f"  •  SUSI {keys_collected}/{keys_required}"
    if keys_collected >= keys_required and (not boss_level or boss is None):
        text="MISSION COMPLETE: TAKAS NA! HANAPIN ANG LABAS"
    elif boss_level and boss is not None:
        text += "  •  TALUNIN MUNA ANG HEPE BAGO TUMAKAS"
    y=SH-42
    main_cv.create_rectangle(24,y-14,SW-24,y+18,fill="#f7edcf",outline="#6f4e37",width=2,tags="game")
    main_cv.create_text(SW/2,y+2,text=text,fill=current_theme()["accent"],font=("Arial",10,"bold"),tags="game")
    main_cv.create_text(SW-34,SH-10,text="WASD / ARROWS  MOVE   •   SPACE  SIPA   •   ESC  PAUSE",anchor="e",fill="#fff8df",font=("Arial",8,"bold"),tags="game")

def animate_maze(my_gen):
    global anim_job, tick_frame
    if my_gen != screen_gen or not in_game:
        return
    tick_frame += 1
    try:
        draw()
    except Exception:
        return
    anim_job = root.after(90, lambda: animate_maze(my_gen))

flash_color = None
flash_until = 0.0

def flash_screen(color, duration=0.15):
    # BUGFIX: this used to create a one-off canvas rectangle and schedule
    # its deletion 120ms later with root.after(). That never actually
    # showed up on screen, because every caller of flash_screen() is
    # immediately followed (later in the same key-press handler) by a
    # call to draw(), which starts with main_cv.delete("all"). The
    # overlay rectangle was created and then wiped again before Tkinter
    # ever got a chance to paint a frame containing it -- so pickups,
    # hits, and vehicle/boss collisions never visibly flashed.
    # Fix: store the flash as timed STATE (like night_mode/celebrating
    # already do correctly) and let draw() render it every frame while
    # it's still active. That survives being called from inside draw().
    global flash_color, flash_until
    if not in_game:
        return
    flash_color = color
    flash_until = time.monotonic() + duration

def bfs_next_step(start_pos, target_pos):
    rows, cols = len(maze), len(maze[0])
    start_pos, target_pos = tuple(start_pos), tuple(target_pos)
    if start_pos == target_pos:
        return list(start_pos)

    visited = {start_pos: None}
    q = deque([start_pos])
    while q:
        cur = q.popleft()
        if cur == target_pos:
            break
        r, c = cur
        for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            nr, nc = r+dr, c+dc
            if 0 <= nr < rows and 0 <= nc < cols and maze[nr][nc] == 0:
                if (nr, nc) not in visited:
                    visited[(nr, nc)] = cur
                    q.append((nr, nc))

    if target_pos not in visited:
        return list(start_pos)

    step = target_pos
    while visited[step] is not None and visited[step] != start_pos:
        step = visited[step]
    return list(step)

def phase_step(e):
    """Ghosts occasionally ignore a single wall and drift straight toward
    the player instead of pathfinding around it -- makes them feel like
    a real threat that can cut you off, not just another chaser."""
    er, ec = e["pos"]
    pr, pc = player
    dr = 0 if pr == er else (1 if pr > er else -1)
    dc = 0 if pc == ec else (1 if pc > ec else -1)
    rows, cols = len(maze), len(maze[0])
    for ddr, ddc in [(dr, 0), (0, dc)]:
        if ddr == 0 and ddc == 0:
            continue
        nr, nc = er + ddr, ec + ddc
        # only phase through an actual WALL cell (maze[nr][nc]==1) that's
        # otherwise blocking a straight line toward the player -- moving
        # through open floor isn't a "phase," it's just normal walking.
        if 0 <= nr < rows and 0 <= nc < cols and maze[nr][nc] == 1:
            # Phase THROUGH one wall, but never place the ghost inside a wall.
            br, bc = nr + ddr, nc + ddc
            if 0 <= br < rows and 0 <= bc < cols and maze[br][bc] == 0:
                return [br, bc]
    return None

def update_vehicles_and_boss():
    global lives, boss, points, combo, combo_timer
    rows, cols = len(maze), len(maze[0])
    for v in vehicles:
        v["timer"] += 1
        if v["timer"] < 4:
            continue
        v["timer"] = 0
        r,c=v["pos"]
        choices=[(r+dr,c+dc) for dr,dc in ((0,1),(0,-1),(1,0),(-1,0))
                 if 0<=r+dr<rows and 0<=c+dc<cols and maze[r+dr][c+dc]==0]
        if choices: v["pos"]=list(random.choice(choices))
        if v["pos"] == player and shield <= 0:
            lives -= 1
            flash_screen("#ff884d")
            play_sound("hit")
            player[:] = [1,1]
            if lives <= 0: game_over()

    if boss:
        boss["timer"] += 1
        if boss["timer"] >= max(2, 6-level//15):
            boss["timer"] = 0
            step=bfs_next_step(boss["pos"], player)
            if step: boss["pos"]=step
        if boss["pos"] == player:
            if shield > 0:
                shield = max(0, shield-4)
            else:
                lives -= 1; player[:] = [1,1]; flash_screen("#ff2222"); play_sound("hit")
                if lives <= 0: game_over()

def move_enemies():
    # Each enemy species moves on its own cadence: spikes are fast, blobs
    # are slow, ghosts are normal speed but can occasionally phase
    # through one wall toward you. speed_boost slows every enemy down.
    slow = 2 if speed_boost > 0 else 1
    for e in enemies:
        stats = ENEMY_STATS[e["kind"]]
        interval = max(1, enemy_tick + stats["interval_delta"]) * slow
        e["timer"] += 1
        if e["timer"] < interval:
            continue
        e["timer"] = 0

        if stats["phase_chance"] > 0 and random.random() < stats["phase_chance"]:
            ghost_hop = phase_step(e)
            if ghost_hop is not None:
                e["pos"] = ghost_hop
                continue

        e["pos"] = bfs_next_step(e["pos"], player)

    for e in enemies:
        if e["pos"] == player:
            hit_by_enemy(e)
            break

def hit_by_enemy(attacker=None):
    global lives, ammo, player
    if ammo > 0:
        ammo -= 1
        nearest = min(enemies, key=lambda e: abs(e["pos"][0]-player[0]) + abs(e["pos"][1]-player[1]))
        nearest["hp"] -= 1
        er, ec = nearest["pos"]
        ex, ey = GAME_X0 + ec*cell + cell/2, GAME_Y0 + er*cell + cell/2
        light, dark = ENEMY_PALETTE[nearest["kind"]]
        spawn_particles(ex, ey, light, n=(14 if nearest["hp"] <= 0 else 6))
        if nearest["hp"] <= 0:
            enemies.remove(nearest)
            combo += 1
            combo_timer = 25
            points += 4 + min(combo, 5)
        flash_screen("#ff884d")
        play_sound("gun")
        return

    px, py = GAME_X0 + player[1]*cell + cell/2, GAME_Y0 + player[0]*cell + cell/2

    if shield > 0:
        spawn_particles(px, py, "#ffee33", n=10, speed=2.0)
        flash_screen("#ffee33")
        play_sound("shield")
        return

    spawn_particles(px, py, "#ff2222", n=16, speed=4.0)
    lives -= 1
    player[:] = [1, 1]
    explored.add((1, 1))
    flash_screen("#ff2222")
    play_sound("hit")

    if lives <= 0:
        game_over()

def game_over():
    global level, points, in_game, game_over_window
    if game_over_window is not None:
        return
    in_game = False
    root.unbind("<KeyPress>")
    points = max(0, points - 5)
    play_sound("gameover")
    save()
    w = tk.Toplevel(root)
    game_over_window = w
    w.title("Nahuli!")
    w.configure(bg="#f3e7c4")
    w.resizable(False, False)
    tk.Label(w, text="NAHULI KA!", fg="#8d2f2f", bg="#f3e7c4",
             font=("Georgia", 20, "bold")).pack(padx=35, pady=(22, 6))
    tk.Label(w, text="Ayusin ang diskarte at subukan ulit.",
             fg="#5d432b", bg="#f3e7c4", font=("Arial", 11)).pack(padx=35, pady=5)
    def back():
        global game_over_window
        if game_over_window is not None:
            try: game_over_window.destroy()
            except tk.TclError: pass
            game_over_window = None
        lobby()
    styled_button(w, "BALIK SA LOBBY", back,
                  fg="#8d2f2f", w=20).pack(pady=14)
    w.protocol("WM_DELETE_WINDOW", back)
    w.transient(root)
    w.grab_set()

def go_home(event=None):
    """Return safely to the barangay home screen from gameplay."""
    if not in_game or game_over_window is not None:
        return
    save()
    lobby()

def restart_level(event=None):
    """Restart the current level without changing the player's level."""
    global paused
    if not in_game or game_over_window is not None:
        return
    paused = False
    clear()
    start()

def show_help(event=None):
    """Open a small in-game guide with controls and mission rules."""
    if not in_game or game_over_window is not None:
        return
    w = tk.Toplevel(root)
    w.title("Gabay sa Mission: Tumakas")
    w.configure(bg="#f3e7c4")
    w.resizable(False, False)
    tk.Label(w, text="📜 GABAY SA BARANGAY", fg="#8d2f2f", bg="#f3e7c4",
             font=("Georgia", 18, "bold")).pack(padx=22, pady=(16, 8))
    guide = (
        "WASD / ARROWS  — galaw\n"
        "SPACE           — SIPA / tira\n"
        "ESC             — PAUSE / RESUME\n"
        "HOME            — balik sa lobby\n"
        "R               — restart ng level\n"
        "F11             — fullscreen on/off\n"
        "SOUND           — music at effects sa game\n\n"
        "MISSION: Kunin ang lahat ng SUSI (laging nakikita sa maze)\n"
        "bago pumunta sa LABAS.\n"
        "Iwasan ang mga kaaway, sasakyan, at gamitin ang items nang wasto."
    )
    tk.Label(w, text=guide, justify="left", fg="#4b3522", bg="#f3e7c4",
             font=("Arial", 10, "bold"), padx=18, pady=8).pack()
    styled_button(w, "ISARA", w.destroy, fg="#8d2f2f", w=18, h=40, font_size=10).pack(pady=(6, 16))
    w.transient(root)
    w.grab_set()

def toggle_sound():
    global sound_enabled
    sound_enabled = not sound_enabled
    if sound_enabled:
        refresh_bgm()
        play_sound("menu")
    else:
        stop_bgm()
    save()
    if in_game:
        draw()

def toggle_pause(event=None):
    global paused
    if not in_game or game_over_window is not None:
        return
    paused = not paused
    if not paused:
        # Minor cleanup: draw() only re-binds "<Button-1>" to pause_click
        # while the pause overlay is showing, but nothing ever unbound it
        # again on resume. pause_click() already no-ops when not paused,
        # so this wasn't exploitable -- just a stray leftover binding.
        root.unbind("<Button-1>")
    draw()

last_direction = (0, 1)

def shoot():
    global ammo, boss, combo, combo_timer, points
    if not in_game or paused or ammo <= 0:
        return
    dr, dc = last_direction
    r, c = player
    rows, cols = len(maze), len(maze[0])
    while True:
        r += dr; c += dc
        if not (0 <= r < rows and 0 <= c < cols) or maze[r][c]:
            break
        if boss and boss["pos"] == [r,c]:
            # BUGFIX: this branch never spent any SIPA ammo, unlike the
            # normal-enemy hit branch below and the "shot hit nothing"
            # fallback at the end of this function. That let a single
            # ammo pickup deal unlimited free damage to the boss.
            ammo -= 1
            boss["hp"] -= 1
            spawn_particles(GAME_X0+c*cell+cell/2, GAME_Y0+r*cell+cell/2, "#f0c83d", n=12)
            if boss["hp"] <= 0:
                points += 25
                combo += 1
                combo_timer = 25
                boss = None
                play_sound("levelup")
            else:
                play_sound("hit")
            draw(); return
        for enemy in list(enemies):
            if enemy["pos"] == [r, c]:
                ammo -= 1
                enemy["hp"] -= 1
                ex = GAME_X0 + c*cell + cell/2
                ey = GAME_Y0 + r*cell + cell/2
                spawn_particles(ex, ey, ENEMY_PALETTE[enemy["kind"]][0], n=10)
                if enemy["hp"] <= 0:
                    enemies.remove(enemy)
                    combo += 1
                    combo_timer = 25
                    points += 4 + min(combo, 5)
                    play_sound("gun")
                else:
                    play_sound("hit")
                draw()
                return
    # Shot spent even when it hits nothing, keeping the resource meaningful.
    ammo -= 1
    play_sound("gun")
    draw()

def move(e):
    global trail, move_count, points, last_direction, keys_collected, event_done, combo, combo_timer
    if not in_game or paused or game_over_window is not None:
        return

    moves = {
        "up":(-1,0), "w":(-1,0),
        "down":(1,0), "s":(1,0),
        "left":(0,-1), "a":(0,-1),
        "right":(0,1), "d":(0,1)
    }

    key = e.keysym.lower()
    if key not in moves:
        return

    dr, dc = moves[key]
    last_direction = (dr, dc)
    nr, nc = player[0]+dr, player[1]+dc

    if 0 <= nr < len(maze) and 0 <= nc < len(maze[0]):
        if maze[nr][nc] == 0:

            if skin != "white":
                x = GAME_X0 + player[1]*cell + cell//2
                y = GAME_Y0 + player[0]*cell + cell//2

                if skin == "bahaghari":
                    col = random.choice(["#b52b3a", "#d49b2a", "#5e8f45", "#2f7d9a", "#7c5aa6"])
                else:
                    col = skins[skin][1]

                trail.insert(0, (x, y, col))
                trail = trail[:6]

            player[:] = [nr, nc]
            explored.add((nr, nc))
            move_count += 1

            collect_key()
            collect_item()

            # Hidden house shortcuts
            if tuple(player) in shortcuts:
                player[:] = list(shortcuts[tuple(player)])
                explored.add(tuple(player))
                points += 2
                spawn_particles(GAME_X0+player[1]*cell+cell/2, GAME_Y0+player[0]*cell+cell/2, "#f0c83d", n=10)
                # BUGFIX (round 2): re-run pickups at the destination tile.
                # create_maze() now avoids placing shortcuts onto a
                # key/item tile in the first place, but this is a cheap
                # safety net in case a future edit reintroduces that.
                collect_key()
                collect_item()

            # NPC interaction: stepping onto a resident gives a hint.
            for n in npcs:
                if n["pos"] == player:
                    flash_screen("#f0c83d")
                    spawn_particles(GAME_X0+player[1]*cell+cell/2, GAME_Y0+player[0]*cell+cell/2, "#f0c83d", n=8)
                    event_done = True if mission_event == "delivery" else event_done

            # Event objectives.
            if mission_event == "missing_key" and not event_done and keys_collected > 0:
                # collecting any key completes the side event; the remaining
                # keys still matter for the main objective.
                event_done = True
                points += 8
            elif mission_event == "delivery" and not event_done and points >= 10:
                event_done = True
                points += 8

            if combo_timer > 0:
                combo_timer -= 1
            elif combo > 0:
                combo = 0

            update_vehicles_and_boss()

            # each enemy now tracks its own per-species cadence (see
            # move_enemies), so we just call it on every player move.
            move_enemies()

            tick_effects()
            draw()

            if player == exit_pos:
                # BUGFIX (round 2): on a boss level the objective text says
                # "TALUNIN ANG HEPE NG BARANGAY" (defeat the barangay
                # chief), but completion here only ever checked the keys —
                # you could walk straight past an undefeated boss and clear
                # the level anyway. Now a boss level also requires boss
                # to be None (defeated) first.
                if keys_collected >= keys_required and (not boss_level or boss is None):
                    complete()
                else:
                    flash_screen("#f0c83d")
                    spawn_particles(GAME_X0 + nc*cell + cell/2, GAME_Y0 + nr*cell + cell/2, "#f0c83d", n=8)

def collect_key():
    global keys_collected, points
    pos = tuple(player)
    if pos in keys:
        keys.pop(pos, None)
        keys_collected += 1
        points += 3
        play_sound("key")
        px, py = GAME_X0 + player[1]*cell + cell/2, GAME_Y0 + player[0]*cell + cell/2
        spawn_particles(px, py, "#f0c83d", n=18, speed=4.0)
        flash_screen("#f0c83d")
        play_sound("item")

def collect_item():
    global ammo, speed_boost, shield, points
    pos = tuple(player)
    if pos in items:
        kind = items.pop(pos)
        if kind == "sipa":
            ammo += 3
        elif kind == "kalesa":
            speed_boost += 15
        elif kind == "payong":
            shield += 15
        elif kind == "mangga":
            points += 5
        px, py = GAME_X0 + player[1]*cell + cell/2, GAME_Y0 + player[0]*cell + cell/2
        spawn_particles(px, py, ITEM_COLORS[kind], n=12, speed=3.5)
        flash_screen(ITEM_COLORS[kind])
        play_sound("gun" if kind == "sipa" else "item")

def tick_effects():
    global speed_boost, shield
    if speed_boost > 0:
        speed_boost -= 1
    if shield > 0:
        shield -= 1

celebrating = False  # true while the "LEVEL CLEAR!" confetti banner plays

def complete():
    global level, points, celebrating, in_game
    if celebrating or not in_game:
        return
    elapsed = max(0.0, time.monotonic() - level_start_time)
    old_best = best_times.get(level)
    if old_best is None or elapsed < old_best:
        best_times[level] = elapsed
    points += 10 + combo * 2

    if level < 100:
        level += 1

    play_sound("levelup")
    save()

    celebrating = True
    cx = GAME_X0 + (cell*len(maze[0]))/2
    confetti_colors = ["#00ffe0", "#ffee33", "#ff66cc", "#b266ff", "#33ccff"]
    for _ in range(5):
        spawn_particles(cx + random.uniform(-140, 140), GAME_Y0 + 30,
                         random.choice(confetti_colors), n=8, speed=2.5, life=45)

    my_gen = screen_gen
    root.after(700, lambda: finish_level_transition(my_gen))

def finish_level_transition(my_gen):
    global celebrating
    celebrating = False
    if my_gen != screen_gen:
        return  # player already left this screen some other way
    lobby()

def sari_sari_store():
    global points, ammo, speed_boost, shield, lives
    w = tk.Toplevel(root)
    w.title("Sari-Sari Store")
    w.configure(bg="#f3e7c4")
    w.resizable(False, False)
    tk.Label(w,text="🏪 SARI-SARI STORE",fg="#2f6f73",bg="#f3e7c4",font=("Georgia",20,"bold")).pack(pady=10)
    status=tk.Label(w,text=f"PUNTOS: {points}",fg="#6b4e2f",bg="#f3e7c4",font=("Arial",12,"bold")); status.pack(pady=5)
    def buy_item(name,cost):
        global points, ammo, speed_boost, shield, lives
        if points < cost: return
        points -= cost
        if name=="Pandesal": ammo += 2
        elif name=="Kape": speed_boost += 12
        elif name=="Payong": shield += 12
        elif name=="Buhay": lives = min(3,lives+1)
        status.config(text=f"PUNTOS: {points}")
        save()
    # BUGFIX (round 2): buy_item's name matching used to be driven by
    # slicing the visible button text apart at " —" (an em dash). Three
    # of the four labels have that separator, but "❤️ Dagdag Buhay" does
    # not, so the old parser produced "Dagdag Buhay" instead of "Buhay"
    # -- which never matched any branch in buy_item(). Clicking it still
    # deducted 20 points every time and gave back nothing at all. Now
    # each button carries its own explicit canonical name instead of
    # re-deriving it from the label text.
    for label, cost, canonical in [
        ("🥖 Pandesal — +2 SIPA", 8, "Pandesal"),
        ("☕ Kape — BILIS", 10, "Kape"),
        ("☂ Payong — KALASAG", 12, "Payong"),
        ("❤️ Dagdag Buhay", 20, "Buhay"),
    ]:
        styled_button(w, label, lambda n=canonical, c=cost: buy_item(n, c), fg="#2f6f73", w=28).pack(pady=4)
    styled_button(w,"ISARA",w.destroy,fg="#8d2f2f",w=28).pack(pady=8)

def shop():
    w = tk.Toplevel(root)
    w.title("Tindahan ng Kasuotan")
    w.configure(bg="#0a0018")
    w.resizable(False, False)

    tk.Label(w, text="TINDAHAN NG KASUOTAN",
             fg="#00ffe0", bg="#0a0018",
             font=("Arial", 20, "bold")).pack(pady=10)

    tk.Label(w, text=f"PUNTOS: {points}",
             fg="#ffee33", bg="#0a0018").pack(pady=5)

    prev = tk.Canvas(w, width=110, height=110, bg="#050505", highlightthickness=0)
    prev.pack(pady=6)

    def animate_preview(t=0):
        if not prev.winfo_exists():
            return
        prev.delete("all")
        bob = math.sin(t/8) * 4
        draw_mini_character(prev, 55, 58, 26, get_color(), bob)
        prev.after(60, lambda: animate_preview(t+1))

    animate_preview()

    styled_button(w, "WHITE - DEFAULT / NO TRAIL",
                  lambda: equip("white", w), fg="white", w=26).pack(pady=4)

    for n, data in skins.items():
        display_fg = "#7b4f9f" if data[1] == "chroma" else data[1]
        # BUGFIX: this always showed "NAME - <cost> PUNTOS", even for
        # skins you already own and even for the one you have equipped
        # right now, with no way to tell them apart before clicking.
        if n == skin:
            label = f"{n.upper()} - EQUIPPED"
        elif n in owned:
            label = f"{n.upper()} - OWNED (I-TAP PARA I-EQUIP)"
        else:
            label = f"{n.upper()} - {data[0]} PUNTOS"
        styled_button(
            w, label,
            (lambda x=n: buy(x, w)), fg=display_fg, w=26
        ).pack(pady=3)

def buy(n, w):
    global points, skin

    if n in owned:
        skin = n
    elif points >= skins[n][0]:
        points -= skins[n][0]
        owned.append(n)
        skin = n
    else:
        return

    save()
    w.destroy()
    lobby()

def equip(n, w):
    global skin
    skin = n
    save()
    w.destroy()
    lobby()

load()
lobby()
root.mainloop()

# Mission: Tumakas is intentionally built from the original maze game.
# Publishing/poster assets are kept outside this gameplay source.
